import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet, Animated } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../App';
import { MenuItem } from '../types';
import { useFocusEffect } from '@react-navigation/native';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export default function HomeScreen({ navigation }: Props) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [fadeAnim] = useState(new Animated.Value(0));

  useFocusEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  });

  return (
    <View style={styles.container}>
      <Animated.View style={{ opacity: fadeAnim }}>
        <Text style={styles.title}>Christoffel’s Menu</Text>
        <Text style={styles.count}>Total Dishes: {menuItems.length}</Text>
        <FlatList
          data={menuItems}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.itemTitle}>{item.name}</Text>
              <Text>{item.description}</Text>
              <Text>{item.course} - ${item.price.toFixed(2)}</Text>
            </View>
          )}
        />
        <Button
          title=" Book now"
          onPress={() => navigation.navigate('AddMenuItem', {
            addMenuItem: (item: MenuItem) => setMenuItems(prev => [...prev, item]),
          })}
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  count: { marginBottom: 20 },
  card: { padding: 10, backgroundColor: '#f2f2f2', marginBottom: 10, borderRadius: 5 },
  itemTitle: { fontWeight: 'bold' },
});