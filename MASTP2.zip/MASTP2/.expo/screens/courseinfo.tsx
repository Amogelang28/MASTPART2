import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { MenuItem } from '../types';

type CourseInfoProps = {
  course: string;
  items: MenuItem[];
};

export default function CourseInfo({ course, items }: CourseInfoProps) {
  const filteredItems = items.filter(item => item.course === course);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Dishes in {course}</Text>
      <FlatList
        data={filteredItems}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.name}</Text>
            <Text>{item.description}</Text>
            <Text>Price: ${item.price.toFixed(2)}</Text>
          </View>
        )}
        ListEmptyComponent={<Text