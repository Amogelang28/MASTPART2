import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { MenuItem } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { useNavigation } from '@react-navigation/native';

type AddDishProps = {
  addMenuItem: (item: MenuItem) => void;
};

export default function AddDish({ addMenuItem }: AddDishProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('Starters');
  const [price, setPrice] = useState('');
  const navigation = useNavigation();

  const handleAdd = () => {
    if (!name || !description || !price) {
      Alert.alert('Missing Input', 'All fields are required.');
      return;
    }

    const newItem: MenuItem = {
      id: uuidv4(),
      name,
      description,
      course,
      price: parseFloat(price),
    };

    addMenuItem(newItem);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Dish Name</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} />

      <Text style={styles.label}>Description</Text>
      <TextInput style={styles.input} value={description} onChangeText={setDescription} />

      <Text style={styles.label}>Course</Text>
      <Picker selectedValue={course} onValueChange={setCourse} style={styles.input}>
        <Picker.Item label="Starters" value="Starters" />
        <Picker.Item label="Mains" value="Mains" />
        <Picker.Item label="Desserts" value="Desserts" />
      </Picker>

      <Text style={styles.label}>Price</Text>
      <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="numeric" />

      <Button title="Add Dish" onPress={handleAdd} />
    </View>
  );
}

