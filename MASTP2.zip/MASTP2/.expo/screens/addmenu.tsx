import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../App';
import { MenuItem } from '../types';
import { v4 as uuidv4 } from 'uuid';

type Props = NativeStackScreenProps<RootStackParamList, 'AddMenuItem'>;

const courseOptions = ['Starters', 'Mains', 'Desserts'];

export default function AddCartItemScreen({ navigation, route }: Props) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState(courseOptions[0]);
  const [price, setPrice] = useState('');

  const handleAdd = () => {
    if (!name || !description || !price) {
      Alert.alert('Validation Error', 'Please fill in all fields.');
      return;
    }

    const newItem: MenuItem = {
      id: uuidv4(),
      name,
      description,
      course,
      price: parseFloat(price),
    };

    navigation.navigate('Home', {
        addMenuItem: (item: MenuItem) => route.params?.addMenuItem?.(item),
      });
      